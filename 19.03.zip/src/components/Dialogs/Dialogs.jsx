import React from "react";
import DialogItem from "./DialogItem/DialogItem";
import Message from "./Message/Message";

import css from './Dialogs.module.css'

const Dialogs = (props) => {

let newMessage = React.createRef();

const handleSendMessage = () => {
    let message = newMessage.current.value;
    alert(message);
}


    return (
        <div className={css.dialogs}>
            <div className={css.dialogsItems}>
                {
                    props.state.dialogsData.map((dialog) => (
                        <DialogItem name={dialog.name} id={dialog.id}/>
                    ))
                }
            </div>
            <div className={css.messages}>
                {
                    props.state.messagesData.map((message) => (
                        <Message message={message.message} id={message.id}/>
                    ))
                }
                <textarea ref={newMessage}></textarea>
                <button onClick={handleSendMessage}>Send</button>
            </div>

        </div>
    )
}
export default Dialogs;
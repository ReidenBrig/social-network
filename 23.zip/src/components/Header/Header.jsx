import React from "react";
import logo from './img/logo.png';

import css from './Header.module.css'


const Header = () => {
    return (
        <header className={css.header}>
            <img src={logo}/>
        </header>
    )
}

export default Header;
import React from "react";

import css from './ProfileInfo.module.css';



const ProfileInfo = () => {
    return (
        <div>
            <div>
                <img className={css.content_img}
                    src='https://phonoteka.org/uploads/posts/2021-04/1618631414_42-phonoteka_org-p-povtoryayushchiisya-fon-55.png'/>
            </div>
            <div className={css.descriptionBlock}>
                ava + dis
            </div>
        </div>
    )

}

export default ProfileInfo;
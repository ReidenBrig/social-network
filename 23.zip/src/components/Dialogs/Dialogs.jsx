import React from "react";
import css from './Dialogs.module.css'
import {NavLink} from "react-router-dom";

const setActive = ({isActive}) => isActive ? css.active : css.dialog;

const DialogItem = (props) => {
    return (

        <div className={css.dialog}>
            <NavLink className={setActive} to={"/dialogs/" + props.id}>
                {props.name}
            </NavLink>

        </div>
    )
}

const Message = (props) => {
    return(
        <div className={css.message}>{props.message}</div>
    )
}

const Dialogs = (props) => {
    return (
        <div className={css.dialogs}>
            <div className={css.dialogsItems}>
                <DialogItem name="Alex" id='1'/>
                <DialogItem name="Ebert" id='2'/>
                <DialogItem name="August" id='3'/>
                <DialogItem name="Loki" id='4'/>
                <DialogItem name="Pol" id='5'/>

            </div>
            <div className={css.messages}>
                <Message message="Hi"/>
                <Message message="Hello"/>
                <Message message="How are you?"/>
            </div>
        </div>
    )
}
export default Dialogs;
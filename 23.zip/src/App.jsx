import './App.css';
import Header from './components/Header/Header';
import Navbar from './components/Navbar/Navbar';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import Profile from "./components/Profile/Profile";
import Dialogs from "./components/Dialogs/Dialogs";


function App(props) {
    return (
        <BrowserRouter>

            <div className='app-wrapper'>
                <Header/>
                <Navbar/>

                <div className="app-wrapper-content">
                    <Routes>
                        <Route path="/profile" element={<Profile/>} />
                        <Route path="/dialogs/*" element={<Dialogs/>} />
                        <Route path="/news" element={<Dialogs/>} />
                        <Route path="/music" element={<Dialogs/>} />
                        <Route path="/settings" element={<Dialogs/>} />


                    </Routes>
                </div>
            </div>
        </BrowserRouter>
    );
}

export default App;
